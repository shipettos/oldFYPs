// PatternsDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Patterns.h"
#include "PatternsDlg.h"
#include ".\patternsdlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CPatternsDlg dialog



CPatternsDlg::CPatternsDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPatternsDlg::IDD, pParent)
	, m_nDisplayOn(0)
	, m_bIgnoreUniquePatterns(TRUE)
	, m_bFixedNGramLength(FALSE)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_strSource = AfxGetApp()->GetProfileString("Options", "Source file");
	m_strDelimiters = AfxGetApp()->GetProfileString("Options", "Delimiters", "\r\n\t!@#$%^&*()_+-={}|\\:\"'?�/.,<>������;��[]");
}

CPatternsDlg::~CPatternsDlg()
{
}

void CPatternsDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_strSource);
	DDX_Control(pDX, IDC_LIST1, m_list);
	DDX_Radio(pDX, IDC_RADIO1, m_nDisplayOn);
	DDX_Check(pDX, IDC_CHECK1, m_bIgnoreUniquePatterns);
	DDX_Text(pDX, IDC_EDIT2, m_strDelimiters);
	DDX_Control(pDX, IDC_STATUS, m_staticStatus);
	DDX_Control(pDX, IDC_SPIN1, m_spinMinPatternLength);
	DDX_Check(pDX, IDC_CHECK2, m_bFixedNGramLength);
}

BEGIN_MESSAGE_MAP(CPatternsDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDOK, OnBnClickedOk)
	ON_BN_CLICKED(IDC_BROWSE, OnBnClickedBrowse)
	ON_NOTIFY(NM_DBLCLK, IDC_LIST1, OnNMDblclkList1)
	ON_NOTIFY(LVN_GETDISPINFO, IDC_LIST1, OnLvnGetdispinfoList1)
	ON_BN_CLICKED(IDC_RADIO1, OnBnClickedRadio1)
	ON_BN_CLICKED(IDC_RADIO2, OnBnClickedRadio1)
	ON_BN_CLICKED(IDC_RADIO3, OnBnClickedRadio1)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_SAVE, OnBnClickedSave)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_CHECK1, OnBnClickedCheck1)
END_MESSAGE_MAP()


// CPatternsDlg message handlers

BOOL CPatternsDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	ListView_SetExtendedListViewStyle(m_list.m_hWnd, LVS_EX_FULLROWSELECT|LVS_EX_GRIDLINES);
	m_list.InsertColumn(0, "Serial", LVCFMT_LEFT, 50, 0);
	m_list.InsertColumn(1, "Pattern", LVCFMT_LEFT, 380, 0);
	m_list.InsertColumn(2, "Frequency", LVCFMT_LEFT, 50, 0);

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	m_spinMinPatternLength.SetRange32(2, 1000);
	m_spinMinPatternLength.SetPos(AfxGetApp()->GetProfileInt("Options", "MinPatternLength", 2));
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CPatternsDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CPatternsDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CPatternsDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

CString Commas(int nValue)
{
	CString str;
	str.Format("%d", nValue);
	nValue = str.GetLength()-3;
	while(nValue > 0)
		str.Insert(nValue, ','), nValue -= 3;
	return str;
}

void CPatternsDlg::OnBnClickedBrowse()
{
	UpdateData(TRUE);

	CFileDialog dlg(TRUE, "", m_strSource, OFN_EXPLORER|OFN_FILEMUSTEXIST, "All Files (*.*) | *.*; ||", this);
	dlg.m_ofn.lpstrTitle = "Choose file";
	if(dlg.DoModal() != IDOK)
		return;
	m_strSource = dlg.GetPathName();
	AfxGetApp()->WriteProfileString("Options", "Source file", m_strSource);

	UpdateData(FALSE);
}

void CopyClipBoard(CString& str)
{
	char *paszBuffer = str.GetBuffer(0);
	int lInFile = (int)strlen(paszBuffer);

	WCHAR *puszBuffer=new WCHAR[lInFile+1];
	memset((BYTE*)puszBuffer,0,(lInFile+1)*sizeof(WCHAR));
	int i = MultiByteToWideChar(1256,0,paszBuffer,lInFile,puszBuffer,lInFile);

	HGLOBAL hgText = GlobalAlloc(GHND, (lInFile+1) *sizeof(char));
	HGLOBAL hgUnicodeText = GlobalAlloc(GHND, (lInFile+1) *sizeof(WCHAR)); 

	char *pszText = (char *)GlobalLock(hgText);
	WCHAR *pszUnicodeText = (WCHAR *)GlobalLock(hgUnicodeText);

	::OpenClipboard(NULL);
	::EmptyClipboard();
	// First Adjust the locale to match the keyboard
	LCID lcid = MAKELCID(MAKELANGID(LANG_ARABIC,SUBLANG_ARABIC_SAUDI_ARABIA),SORT_DEFAULT);
	::SetClipboardData(CF_LOCALE,(HANDLE)lcid);

	//Get the text to paste to the clipboard
	wcscpy(pszUnicodeText,puszBuffer);
	::SetClipboardData(CF_UNICODETEXT, hgUnicodeText);
	::GlobalUnlock(hgUnicodeText);

	strcpy(pszText,paszBuffer);
	::SetClipboardData(CF_TEXT, hgText);
	::GlobalUnlock(hgText); 

	::CloseClipboard();
}

void CPatternsDlg::OnNMDblclkList1(NMHDR *pNMHDR, LRESULT *pResult)
{
	int nItem = m_list.GetSelectionMark();
	if(nItem == -1)
		return;
	CString str = CString((char*)m_vPatterns[nItem]->m_pBuffer, m_vPatterns[nItem]->m_nLength);
	CopyClipBoard(str);

	*pResult = 0;
}

void CPatternsDlg::OnLvnGetdispinfoList1(NMHDR *pNMHDR, LRESULT *pResult)
{
	NMLVDISPINFO *pDispInfo = reinterpret_cast<NMLVDISPINFO*>(pNMHDR);
	
	int nItem = pDispInfo->item.iItem;
	int nSubItem = pDispInfo->item.iSubItem;
	static CString str;
	if(nSubItem == 0)
		str.Format("%s", Commas(nItem+1));
	else	if(nSubItem == 1)
		str = CString((char*)m_vPatterns[nItem]->m_pBuffer, m_vPatterns[nItem]->m_nLength);
	else	if(nSubItem == 2)
		str = Commas(m_vPatterns[nItem]->m_nFrequency);

	pDispInfo->item.pszText = str.GetBuffer(0);
	*pResult = 0;
}

void CPatternsDlg::OnBnClickedOk()
{
	UpdateData(TRUE);

	CFile file(m_strSource, CFile::modeRead|CFile::shareDenyNone);
	int nSrcLen = (int)file.GetLength();
	BYTE* pSrc = new BYTE[nSrcLen+1];
	file.Read(pSrc, nSrcLen);
	file.Close();
	pSrc[nSrcLen] = 0;

	int nMinPatternLength = m_spinMinPatternLength.GetPos();

	DWORD dwTime = ::GetTickCount();
	BeginWaitCursor();
	m_pa.ConstructPatterns(pSrc, nSrcLen, m_strDelimiters, nMinPatternLength, m_bFixedNGramLength?true:false);
	EndWaitCursor();
	delete pSrc;

	OnBnClickedRadio1();

	dwTime = ::GetTickCount()-dwTime;

	m_staticStatus.SetWindowText(Commas(m_pa.GetPatternCount())+ " Patterns found in "+Commas(nSrcLen/1024)+" KB - "+Commas(dwTime)+" ms elapsed");
}

void CPatternsDlg::OnBnClickedRadio1()
{
	UpdateData(TRUE);

	BeginWaitCursor();
	m_pa.GetPatterns(m_nDisplayOn, m_bIgnoreUniquePatterns?true:false, m_vPatterns);
	EndWaitCursor();

	m_list.SetItemCount(m_vPatterns.size());
}

void CPatternsDlg::OnDestroy()
{
	CDialog::OnDestroy();

	UpdateData(TRUE);

	AfxGetApp()->WriteProfileString("Options", "Delimiters", m_strDelimiters);
	AfxGetApp()->WriteProfileInt("Options", "MinPatternLength", m_spinMinPatternLength.GetPos());
}

void CPatternsDlg::OnBnClickedSave()
{
	CString strFile = AfxGetApp()->GetProfileString("Options", "Save file");
	CFileDialog dlg(FALSE, "", strFile, OFN_EXPLORER, "All Files (*.*) | *.*; ||", this);
	dlg.m_ofn.lpstrTitle = "Choose file to save patterns";
	if(dlg.DoModal() != IDOK)
		return;
	strFile = dlg.GetPathName();
	AfxGetApp()->WriteProfileString("Options", "Save file", strFile);

	CFile file(strFile, CFile::modeCreate|CFile::modeWrite|CFile::shareDenyNone);

	BeginWaitCursor();
	CString str;
	int nItemCount = m_list.GetItemCount();
	for(int nItem = 0; nItem < nItemCount; nItem++)
	{
		str.Format("%d\t%s\t%s\r\n", nItem+1, m_list.GetItemText(nItem, 1), m_list.GetItemText(nItem, 2));
		file.Write(str, str.GetLength());
	}
	EndWaitCursor();
}

void CPatternsDlg::OnTimer(UINT nIDEvent)
{

	CDialog::OnTimer(nIDEvent);
}

void CPatternsDlg::OnBnClickedCheck1()
{
	OnBnClickedRadio1();
}
