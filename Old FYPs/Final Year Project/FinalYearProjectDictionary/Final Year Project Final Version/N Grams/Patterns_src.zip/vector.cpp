// vector.cpp
//
//////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "vector.h"

void *AllocPtr(int nSize)
{
	void *p = malloc(nSize);
	nSize = (int)_msize(p);
	return memset(p, 0, nSize);
}

void *ReAllocPtr(void *p, int nSize)
{
	int nOldSize = (int)_msize(p);
	p = realloc(p, nSize);
	if(nSize > nOldSize)
	{
		nSize = (int)_msize(p);
		memset((char*)p+nOldSize, 0, nSize-nOldSize);
	}
	return p;
}

void FreePtr(void *p)
{
	free(p);
}

VectorData::VectorData():m_nGrowBytes(128)
{
	InitValues();
}

VectorData::VectorData(const VectorData& data):m_nGrowBytes(128)
{
	InitValues();
	Assign(data.m_pBuffer, data.GetLength());
}

VectorData::~VectorData()
{
	if(m_nAllocLength)
		FreePtr(m_pBuffer);
}

void VectorData::InitValues()
{
	m_pBuffer = "\0";
	m_nAllocLength = 0;
	m_nLength = 0;			
}

void VectorData::AllocBuffer(int nAllocLength)
{
	if(m_nAllocLength == 0)
		m_pBuffer = (char*)AllocPtr(nAllocLength);
	else
		m_pBuffer = (char*)ReAllocPtr(m_pBuffer, nAllocLength);
	m_nAllocLength = nAllocLength;
}

void VectorData::ReleaseBuffer(int nNewLength /*= -1*/)
{
	if(nNewLength == -1)
		nNewLength = (int)strlen(m_pBuffer);
	if(nNewLength == 0)
		Empty();
	else	if(nNewLength >= m_nAllocLength)
		AllocBuffer(nNewLength+m_nGrowBytes+1);
	m_nLength = nNewLength;
	if(m_nLength)
		m_pBuffer[m_nLength] = 0;
}

void VectorData::Empty()
{
	if(m_nAllocLength)
		FreePtr(m_pBuffer);
	InitValues();
}

void VectorData::Append(char* pBuffer, int nLength)
{
	int nCurLength = m_nLength;
	ReleaseBuffer(m_nLength+nLength);
	memcpy(m_pBuffer+nCurLength, pBuffer, nLength);
}

int VectorData::Delete(int nIndex, int nCount /*= 1*/ )
{
	if (nIndex < 0)
		nIndex = 0;
	int nNewLength = m_nLength;
	if (nCount > 0 && nIndex < nNewLength)
	{
		int nBytesToCopy = nNewLength - (nIndex + nCount) + 1;

		memmove((char*)m_pBuffer + nIndex, m_pBuffer + nIndex + nCount, nBytesToCopy * sizeof(TCHAR));
		ReleaseBuffer(nNewLength - nCount);
	}

	return nNewLength;
}

int VectorData::Insert(int nIndex, char* pBuffer, int nLength)
{
	if(nIndex > m_nLength || nLength <= 0)
		return m_nLength;
	int nCurLength = m_nLength;
	ReleaseBuffer(m_nLength+nLength);
	memmove(m_pBuffer+nIndex+nLength, m_pBuffer+nIndex, nCurLength-nIndex);
	memcpy(m_pBuffer+nIndex, pBuffer, nLength);
	return m_nLength;
}

const VectorData& VectorData::Assign(char* pBuffer, int nLength)
{
	if(pBuffer && nLength > 0)
	{
		ReleaseBuffer(nLength);
		memcpy(m_pBuffer, pBuffer, nLength);
	}
	else
		Empty();
	return *this;
}