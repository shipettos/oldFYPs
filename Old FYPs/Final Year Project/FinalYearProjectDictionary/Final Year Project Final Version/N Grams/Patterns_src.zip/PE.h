// PE.h
//
//////////////////////////////////////////////////////////////////////

#pragma once

#include "BinaryTree.h"
#include "vector.h"

//////////////////////////////////////////////////////////////////////
template <class VALUE> class CValue
{
public:
	CValue()
	{
		m_nKey = 0;
	}
public:
	VALUE m_nKey;
	int compare(VALUE nKey)
	{	return nKey == m_nKey ? 0 : (m_nKey > nKey ? 1 : -1);	}
	void operator=(VALUE nKey) { m_nKey = nKey;	}
	bool operator==(VALUE nKey) { return compare(nKey) == 0;	}
};

class CPattern
{
public:
	CPattern()	{}
	CPattern(BYTE* pBuffer, int nLength) { m_pBuffer = pBuffer, m_nLength = nLength;	}
	CPattern(const CPattern& buffer) { *this = buffer;	}

public:
	BYTE* m_pBuffer;
	int m_nLength;
	int m_nFrequency;
	inline int compare(const CPattern* buffer)
	{
		int nResult = memcmp(m_pBuffer, buffer->m_pBuffer, min(m_nLength, buffer->m_nLength));
		if(nResult != 0 || m_nLength == buffer->m_nLength)
			return nResult;
		return m_nLength > buffer->m_nLength ? 1 : -1;
	}
	inline void operator=(const CPattern* buffer) { m_pBuffer = buffer->m_pBuffer;	m_nLength = buffer->m_nLength;	}
};

class CPatternAlaysis
{
public:
	CPatternAlaysis();

protected:
	BYTE* m_pDes;
	CBinaryTree<CPattern, CPattern*, int, int> m_alpDic;

public:
	void ConstructPatterns(IN BYTE *pSrc, IN int nSrcLen, IN LPCSTR lpcsDelimiters = NULL, int nMinPatternWords = 2, bool bFixedNGram = false);
	void GetPatterns(IN int nSortType, IN bool bIgnoreUniquePatterns, OUT vector<CPattern*>& vPatterns);
	int GetPatternCount();
};

