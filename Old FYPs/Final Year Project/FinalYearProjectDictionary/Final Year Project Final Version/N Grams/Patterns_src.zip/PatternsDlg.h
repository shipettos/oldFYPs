// PatternsDlg.h : header file
//

#pragma once
#include "afxcmn.h"

#include "vector.h"
#include "pe.h"
#include "afxwin.h"

// CPatternsDlg dialog
class CPatternsDlg : public CDialog
{
// Construction
public:
	CPatternsDlg(CWnd* pParent = NULL);	// standard constructor
	~CPatternsDlg();

// Dialog Data
	enum { IDD = IDD_PATTERNS_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

	CPatternAlaysis m_pa;
// Implementation
protected:
	HICON m_hIcon;

	vector<CPattern*> m_vPatterns;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedBrowse();
	CString m_strSource;
	CListCtrl m_list;
	afx_msg void OnNMDblclkList1(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnLvnGetdispinfoList1(NMHDR *pNMHDR, LRESULT *pResult);
	int m_nDisplayOn;
	afx_msg void OnBnClickedRadio1();
	BOOL m_bIgnoreUniquePatterns;
	CString m_strDelimiters;
	afx_msg void OnDestroy();
	afx_msg void OnBnClickedSave();
	CStatic m_staticStatus;
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnBnClickedCheck1();
	CSpinButtonCtrl m_spinMinPatternLength;
	BOOL m_bFixedNGramLength;
};
